﻿using FbAuthTestAli.Interfaces;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Essentials;
using Firebase.Auth;
using FbAuthTestAli.iOS;

[assembly: Dependency(typeof(IOSAuth))]
namespace FbAuthTestAli.iOS
{
    public class IOSAuth : IFbAuth
    {
        public async Task<string> DoLoginWithEP(string E, string P)
        {
            try
            {
                
                var user = await Auth.DefaultInstance.SignInWithPasswordAsync(E,P);
                return await user.User.GetIdTokenAsync();
            }
            catch (Exception err)
            {
                return err.Message;
            }
        }

        public async Task<string> DoRegisterWithEP(string E, string P)
        {
            try
            {
                var user = await Auth.DefaultInstance.CreateUserAsync(E,P);
                var token = await user.User.GetIdTokenAsync();
                return token;
            }
            catch (Exception err)
            {
                return err.Message;
            }
        }
    }
}