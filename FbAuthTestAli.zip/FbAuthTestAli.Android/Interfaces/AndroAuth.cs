﻿using FbAuthTestAli.Interfaces;
using System;
using System.Threading.Tasks;
using Firebase.Auth;
using Xamarin.Forms;
using FbAuthTestAli.Droid.Interfaces;
using Xamarin.Essentials;

[assembly: Dependency(typeof(AndroAuth))]
namespace FbAuthTestAli.Droid.Interfaces
{
    public class AndroAuth : IFbAuth
    {
        public async Task<string> DoLoginWithEP(string E, string P)
        {
            try
            {
                var user = await FirebaseAuth.Instance.SignInWithEmailAndPasswordAsync(E,P);
                var token = await user.User.GetIdTokenAsync(false);
                return token.Token;
            }
            catch (FirebaseAuthInvalidUserException err)
            {
                err.PrintStackTrace();
                return err.Message;
            }
            
            catch(Exception exc)
            {
                Console.WriteLine(exc.Message);
                return exc.Message;
            }
        }

        public async Task<string> DoRegisterWithEP(string E, string P)
        {
            try
            {
                var user = await FirebaseAuth.Instance.CreateUserWithEmailAndPasswordAsync(E,P);
                var token = await user.User.GetIdTokenAsync(false);
                return token.Token;
            }
            catch (FirebaseAuthInvalidUserException err)
            {
                err.PrintStackTrace();
                return err.Message;
            }
            catch(Exception exc)
            {
                Console.WriteLine(exc.Message);
                return exc.Message;
            }
        }
    }
}