﻿using FbAuthTestAli.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace FbAuthTestAli
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        IFbAuth auth;
        public MainPage()
        {
            InitializeComponent();
            auth = DependencyService.Get<IFbAuth>();
        }

        private async void btnLogin_Clicked(object sender, EventArgs e)
        {
            var token = await auth.DoLoginWithEP(txtMail.Text,txtPass.Text);
            await DisplayAlert("Bilgi",token,"OK");
        }

        private async void btnRegister_Clicked(object sender, EventArgs e)
        {
            var token = await auth.DoRegisterWithEP(txtMail.Text,txtPass.Text);
            await DisplayAlert("Bilgi",token,"OK");
        }
    }
}
