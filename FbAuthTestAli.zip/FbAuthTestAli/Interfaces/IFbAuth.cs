﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace FbAuthTestAli.Interfaces
{
    public interface IFbAuth
    {
        Task<string> DoLoginWithEP(string E,string P);
        Task<string> DoRegisterWithEP(string E,string P);
    }
}
